package bean;

public class signupbean {
	private String firstname;
	private String lastname;
	private String email;
	private String password;
	private String radio;
	public String getfirstname() {
		
		return firstname;
	}

	public void setfirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getlastname() {
		
		return lastname;
	}

	public void setlastname(String lastname) {
		this.lastname = lastname;
	}

	public String getemail() {
		
		return email;
	}

	public void setemail(String email) {
		this.email = email;
	}

	public String getpassword() {
		return password;
	}
	public void setpassword(String password) {
		this.password = password;
	}
	public String getradio() {
		return radio;
	}
	public void setradio(String radio) {
		this.radio = radio;
	}

}
